import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
%matplotlib inline

train = pd.read_csv("C:/Users/Admin/Desktop/New folder/data5/train.csv") 
train.head()

test = pd.read_csv("C:/Users/Admin/Desktop/New folder/data5/test.csv")  
test.head()

#data cleaning : checking missing values in each column of train
train.apply(lambda x: sum(x.isnull()),axis = 0)

#data cleaning : checking missing values in each column of test
test.apply(lambda x: sum(x.isnull()),axis = 0)

train['Gender'].value_counts()
train.Gender = train.Gender.fillna('Male')
train['Married'].value_counts()
train.Married = train.Married.fillna('Yes')
train['Dependents'].value_counts()
train.Dependents = train.Dependents.fillna('0')
train['Self_Employed'].value_counts()
train.Self_Employed = train.Self_Employed.fillna('No')
train.LoanAmount = train.LoanAmount.fillna(train.LoanAmount.mean())
train['Loan_Amount_Term'].value_counts()
train.Loan_Amount_Term = train.Loan_Amount_Term.fillna(360.0)
train['Credit_History'].value_counts()
train.Credit_History = train.Credit_History.fillna(1.0)
train.apply(lambda x: sum(x.isnull()),axis=0)


test['Gender'].value_counts()
test.Gender = test.Gender.fillna('Male')
test['Married'].value_counts()
test.Married = test.Married.fillna('Yes')
test['Dependents'].value_counts()
test.Dependents = test.Dependents.fillna('0')
test['Self_Employed'].value_counts()
test.Self_Employed = test.Self_Employed.fillna('No')
test.LoanAmount = test.LoanAmount.fillna(test.LoanAmount.mean())
test['Loan_Amount_Term'].value_counts()
test.Loan_Amount_Term = test.Loan_Amount_Term.fillna(360.0)
test['Credit_History'].value_counts()
test.Credit_History = test.Credit_History.fillna(1.0)
test.apply(lambda x: sum(x.isnull()),axis=0)


train.head()
test.head()

#splitting the training data

X_train = train.iloc[:, 1: 12].values
Y_train = train.iloc[:, 12].values
X_train
Y_train


# Encoding categorical data
# Encoding the Independent Variable

from sklearn.preprocessing import LabelEncoder, OneHotEncoder
labelencoder_X = LabelEncoder()
for i in range(0, 5):
    X_train[:,i] = labelencoder_X.fit_transform(X_train[:,i])
X_train[:,9] = labelencoder_X.fit_transform(X_train[:,9])
X_train[:,10] = labelencoder_X.fit_transform(X_train[:,10])
onehotencoder = OneHotEncoder(categorical_features = [7])
X_train = onehotencoder.fit_transform(X_train).toarray()

# Encoding the Dependent Variable

labelencoder_y = LabelEncoder()
Y_train = labelencoder_y.fit_transform(Y_train)

Y_train

# Splitting training data

X_test = test.iloc[:, 1: 12].values
Y_test = test.iloc[:, 12].values
X_test
Y_test
test.info()


# Encoding categorical data
# Encoding the Independent Variable

from sklearn.preprocessing import LabelEncoder, OneHotEncoder
labelencoder_X = LabelEncoder()
for i in range(0, 5):
    X_test[:,i] = labelencoder_X.fit_transform(X_test[:,i])
X_test[:,9] = labelencoder_X.fit_transform(X_test[:,9])
X_test[:,10] = labelencoder_X.fit_transform(X_test[:,10])

onehotencoder = OneHotEncoder(categorical_features = [7])
X_test = onehotencoder.fit_transform(X_test).toarray()

# Encoding the Dependent Variable

labelencoder_y = LabelEncoder()
Y_test = labelencoder_y.fit_transform(Y_test)

Y_test


# Feature Scaling :Feature Scaling is a technique to standardize the independent features present in the data in a fixed range. 
#It is performed during the data pre-processing to handle highly varying magnitudes or values or units. 
#If feature scaling is not done, then a machine learning algorithm tends to weigh greater values, higher and consider smaller values as the lower values, regardless of the unit of the values.
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.fit_transform(X_test)


#Applying Classification Algorithms
#Logistic Regression
# Fitting Logistic Regression to the Training set
from sklearn.linear_model import LogisticRegression
classifier = LogisticRegression(random_state = 0)
classifier.fit(X_train, Y_train)


# Predicting the Test set results
y_pred = classifier.predict(X_test)

y_pred

# Measuring Accuracy
from sklearn import metrics
print('The accuracy of Logistic Regression is: ', metrics.accuracy_score(y_pred, Y_test))


# Making the Confusion Matrix
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(Y_test, y_pred)

cm

#Decision Tree Classification 

# Fitting Decision Tree Classification to the Training set
from sklearn.tree import DecisionTreeClassifier
classifier = DecisionTreeClassifier(criterion = 'entropy', random_state = 0)
classifier.fit(X_train, Y_train)

# Predicting the Test set results
y_pred = classifier.predict(X_test)
y_pred

# Measuring Accuracy
from sklearn import metrics
print('The accuracy of Decision Tree Classifier is: ', metrics.accuracy_score(y_pred, Y_test))



# Making confusion matrix
from sklearn.metrics import confusion_matrix
print(confusion_matrix(Y_test, y_pred))

#RESULTS :
#The accuracy of Logistic Regression is: 0.8713355048859935
#The accuracy of Decision Tree Classifier is: 1.0
