# -*- coding: utf-8 -*-
"""
Created on Fri Apr 19 19:08:33 2019

@author: Sanmoy
"""

import os
path="C:\\F\\myProjects\\course5"
os.chdir(path)
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


df_conv = pd.read_csv("data/weeklyData.csv")
df_conv.head(3)
len(df_conv.columns)

df_conv.revenue = df_conv.revenue.replace('[\$,]', '', regex=True).astype(np.int64)
df_conv.aov = df_conv.aov.replace('[\$,]', '', regex=True).astype(np.int64)
df_conv.abandoned_revenue = df_conv.abandoned_revenue.replace('[\$,]', '', regex=True).astype(np.int64)

df_conv['abandonment_rate'] = df_conv['abandonment_rate'].replace('[\%,]', '', regex=True).astype(np.float64)
df_conv.conversion_rate = df_conv.conversion_rate.replace('[\%,]', '', regex=True).astype(np.float64)

df_conv.to_csv("analysis/conv_data.csv")

df_1 = df_conv.iloc[:, 2:25]
corr = df_1.corr()
#corr.to_csv("analysis/corrMatrix.csv")
sns.heatmap(corr)

####From correlation plot highly correlated variables are removed
cols_keep = ['week_start_date', 'unique_visitors', 'orders', 'aov',
       'cart_open_to_checkout_initiation', 'checkout_initiation_to_orders',
       'upt', 'visit_depth', 'avg_session_duration', 'page_views_per_visitor',
       'click_throughs', 'internal_searches', 'shop_visits', 'visit_duration',
       'orders/#_of_internal_searches', 'conversion_rate']

#df_rev1 = pd.read_csv("data/revdata.csv")
df_conv1 = df_conv.loc[:, cols_keep]


###Creation of lagged variables
def buildLagStructure(df):
    test_df = pd.DataFrame()
    for i in range(2, 8):
        for j in df.columns:
            name = j+'_lag'+str(i)
            test_df[name] = df[j].shift(i)
    return(test_df) 
    
lagged_df=buildLagStructure(df_conv1.iloc[:, 1:15])
len(lagged_df.columns)

afterLag_df = pd.concat([df_conv1.iloc[:, 0:16], lagged_df], axis=1)
afterLag_df = afterLag_df.dropna()
#afterLag_df.to_csv('analysis/afterLag.csv')    



####Lasso Regression done to do feature selection
from sklearn.linear_model import LassoCV
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

cols = list(afterLag_df)
cols.insert(0, cols.pop(cols.index('conversion_rate')))
rev_df1 = afterLag_df.ix[:, cols]
#rev_df1 = rev_df1.dropna()



X_conv = rev_df1.iloc[:, 2:100]
Y_conv = rev_df1.conversion_rate
X_conv_train, X_conv_test, y_conv_train, y_conv_test=train_test_split(X_conv, Y_conv, test_size=0.3, random_state=31)


lasso_rev = LassoCV(cv=5, random_state=0)
lasso_rev.fit(X_conv_train, y_conv_train)
lasso_rev.coef_


#X_conv_train.columns
x=np.argwhere(lasso_rev.coef_ != 0)

colsF=['week_start_date', 'conversion_rate']
for i in x:
    colsF.append(X_conv_train.columns[i[0]])


train_rev_score=lasso_rev.score(X_conv_train, y_conv_train)
test_rev_score=lasso_rev.score(X_conv_test, y_conv_test)
coeff_rev_used = np.sum(lasso_rev.coef_!=0)
print("Rev training score for alpha=0.0001:", train_rev_score)
print("Rev test score for alpha =0.0001: ", test_rev_score)
print("Rev number of features used: for alpha =0.0001:", coeff_rev_used)


y_conv_pred=lasso_rev.predict(X_conv_test)
lasso_mse=mean_squared_error(y_conv_test, y_conv_pred)

def create_df():
    act_rev_df = pd.DataFrame()
    for i in colsF:
        act_rev_df[i]=rev_df1[i]
    return(act_rev_df)
act_conv_df=create_df()


#corr1 = act_rev_df.iloc[:, 1:21].corr()
#corr.to_csv("analysis/corrMatrix.csv")

act_conv_df['week_start_date'] = pd.to_datetime(act_conv_df['week_start_date'], format="%d-%m-%Y")
act_conv_df=act_conv_df.set_index('week_start_date')     


###Variables are removed having higher vif
import statsmodels.formula.api as smf
from statsmodels.stats.outliers_influence import variance_inflation_factor

#multiregression
lm = smf.ols(formula='conversion_rate ~ unique_visitors+orders+click_throughs+internal_searches+unique_visitors_lag2+click_throughs_lag2+visit_duration_lag2+click_throughs_lag3+internal_searches_lag3+visit_duration_lag3+unique_visitors_lag4+click_throughs_lag4+click_throughs_lag5+internal_searches_lag5+unique_visitors_lag6+internal_searches_lag6+visit_duration_lag6+unique_visitors_lag7+click_throughs_lag7+internal_searches_lag7+visit_duration_lag7', data=act_conv_df).fit()

variables = lm.model.exog
vif = [variance_inflation_factor(variables, i) for i in range(variables.shape[1])]
vif

xcols = ['unique_visitors','orders','click_throughs','internal_searches','unique_visitors_lag2','click_throughs_lag2','visit_duration_lag2','click_throughs_lag3','internal_searches_lag3','visit_duration_lag3','unique_visitors_lag4','click_throughs_lag4','click_throughs_lag5','internal_searches_lag5','unique_visitors_lag6','internal_searches_lag6','visit_duration_lag6','unique_visitors_lag7','click_throughs_lag7','internal_searches_lag7','visit_duration_lag7']
corr1_df=act_conv_df.loc[:, xcols]
corr1 = corr1_df.corr()
corr1.to_csv("analysis/corrMatrix3.csv")


lm_1 = smf.ols(formula='conversion_rate ~ unique_visitors+orders+internal_searches+unique_visitors_lag2+visit_duration_lag2+click_throughs_lag3+unique_visitors_lag4+click_throughs_lag5+internal_searches_lag5+unique_visitors_lag6+unique_visitors_lag7', data=act_conv_df).fit()
variables_1 = lm_1.model.exog
vif_1 = [variance_inflation_factor(variables_1, i) for i in range(variables_1.shape[1])]
vif_1

xcols_1 = ['unique_visitors','orders','internal_searches','unique_visitors_lag2','visit_duration_lag2','click_throughs_lag3','unique_visitors_lag4','click_throughs_lag5','internal_searches_lag5','unique_visitors_lag6','unique_visitors_lag7']
corr2_df=act_conv_df.loc[:, xcols_1]
corr2 = corr2_df.corr()
corr2.to_csv("analysis/corrMatrix4.csv")


#### External Regressors
#from sklearn import preprocessing
#standardized_rev = preprocessing.scale(act_rev_df)
#standardized_rev_df=pd.DataFrame(standardized_rev, index=act_rev_df.index, columns=act_rev_df.columns)

###Splitting into Train and Test set
strain, stest = act_conv_df[:70], act_conv_df[70:]
strain.shape
stest.shape

#from statsmodels.tsa.arima_model import ARIMA
#from statsmodels.tsa.statespace.sarimax import SARIMAX
from pyramid.arima.stationarity import ADFTest
from pyramid.arima import auto_arima

###ADF test to check stationarity
adf_test = ADFTest(alpha=0.05)   
adf_test.is_stationary(act_conv_df.conversion_rate)

###Fitted seasonal ARIMA Model with external regressors
exog_train=strain[['unique_visitors','orders','internal_searches','unique_visitors_lag2','visit_duration_lag2','click_throughs_lag3','unique_visitors_lag4','click_throughs_lag5','internal_searches_lag5','unique_visitors_lag6','unique_visitors_lag7']]
sarima_model=auto_arima(strain[['conversion_rate']], exogenous=exog_train,
                           start_p=1, start_q=1,
                           test='adf',
                           max_p=3, max_q=3, m=52,
                           start_P=0, seasonal=True,
                           d=None, D=1, trace=True,
                           error_action='ignore',  
                           suppress_warnings=True, 
                           stepwise=True)
sarima_model.summary()

###Test Prediction
exog_test=stest[['unique_visitors','orders','internal_searches','unique_visitors_lag2','visit_duration_lag2','click_throughs_lag3','unique_visitors_lag4','click_throughs_lag5','internal_searches_lag5','unique_visitors_lag6','unique_visitors_lag7']]
exog_test.shape
sprediction=pd.DataFrame(sarima_model.predict(n_periods=31, exogenous=exog_test), index=stest.index)
sprediction.columns=['conversion_rate']

plt.figure(figsize=(8,6))
plt.plot(strain.conversion_rate, label='Training')
plt.plot(stest.conversion_rate, label='Test')
plt.plot(sprediction, label='Predicted')      
plt.legend(loc='upper center')
plt.show()

stest['Predicted_conversion_rate'] = sprediction
stest['Error']=stest['conversion_rate']-stest['Predicted_conversion_rate']

#stest_1=stest[['unique_visitors','orders', 'unique_visitors_lag2','unique_visitors_lag3','internal_searches_lag3','click_throughs_lag4','unique_visitors_lag5','visit_duration_lag5','unique_visitors_lag6','internal_searches_lag6','click_throughs_lag7', 'revenue', 'Predicted_Revenue']]
#stest_1.to_csv('analysis/stest.csv')

sarima_mse=mean_squared_error(stest.conversion_rate, stest.Predicted_conversion_rate)



import datetime
start = datetime.datetime.strptime("17-09-2018", "%d-%m-%Y")
end = datetime.datetime.strptime("24-06-2019", "%d-%m-%Y")
date_generated = [start + datetime.timedelta(days=x*7) for x in range(0,41)]

unknown_lst=[]
for date in date_generated:
    x=dict()
    x['week_start_date'] = date.strftime("%Y-%m-%d")
    #x['rev'] = "NA"
    unknown_lst.append(x)

unknown_df = pd.DataFrame(unknown_lst)
#unknown_df.columns=['week_start_date']
unknown_df = unknown_df.set_index('week_start_date')



####Unknown Data Prediction
act_rev_df1 = pd.DataFrame()
act_rev_df1['conversion_rate']=act_conv_df.conversion_rate
train, test = act_rev_df1[:70], act_rev_df1[70:]
train.shape
test.shape

plt.plot(train)
plt.plot(test)
plt.show()


arima_model=auto_arima(train, start_p=1, start_q=1,
                          test='adf', 
                          max_p=8, max_q=8, start_P=0, start_Q=0,
                          max_P=8, max_Q=8,
                          m=52, seasonal=True,
                          d=None, D=1, trace=True,
                          error_action='ignore',  
                          suppress_warnings=True, 
                          stepwise=True, random_state=20, n_fits=30)
 
arima_model.summary()            

prediction = pd.DataFrame(arima_model.predict(n_periods=31), index=test.index)
prediction.columns=['conversion_rate']

plt.figure(figsize=(8,6))
plt.plot(train, label='Training')
plt.plot(test, label='Test')
plt.plot(prediction, label='Predicted')      
plt.legend(loc='upper center')
plt.show()


test['Predicted_conversion_rate'] = prediction
test['Error']=test['conversion_rate']-test['Predicted_conversion_rate']
test

arima_mse=mean_squared_error(test.conversion_rate, test.Predicted_conversion_rate)


prediction1=pd.DataFrame(arima_model.predict(n_periods=41), index=unknown_df.index)
prediction1.columns=['conversion_rate']
unknown_prediction=prediction1['2019-04-15':'2019-06-24']

x = pd.concat([test.Predicted_conversion_rate, unknown_prediction.conversion_rate], axis=0)

plt.figure(figsize=(8,6))
plt.plot(train, label='Training')
plt.plot(test.conversion_rate, label='Test')
plt.plot(x, label='Prediction')        
plt.legend(loc='upper center')
plt.show()
