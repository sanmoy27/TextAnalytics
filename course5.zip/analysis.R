library(TTR)
library(tseries)
library(forecast)
library(devtools)
library(xts)
library(fpp)


setwd("C:\\F\\myProjects\\course5")

#Read CSV
revenue_data <- read.csv("./data/data_revenue.csv", header = T, stringsAsFactors = F)
View(revenue_data)


myTS <- ts(revenue_data$revenue, start=c(2017, 1), end=c(2019, 4), frequency=52)
plot.ts(myTS)
decompose(myTS)
plot(decompose(myTS))
adf.test(myTS)


train <- myTS[1:100]
test <- myTS[101:108]


arima.fit <- auto.arima(myTS)
arima.fit

revenue_forecast<-forecast(arima.fit, h=8)
plot(revenue_forecast, shaded = TRUE, shadecols = "oldstyle")
