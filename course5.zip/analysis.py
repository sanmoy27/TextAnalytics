# -*- coding: utf-8 -*-
"""
Created on Fri Apr 12 22:29:35 2019

@author: PAULSA-CONT
"""

import os
path="C:\\F\\myProjects\\course5"
os.chdir(path)
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


df = pd.read_csv("data/weeklyData.csv")
df.head(3)
len(df.columns)




df.revenue = df.revenue.replace('[\$,]', '', regex=True).astype(np.int64)
df.aov = df.aov.replace('[\$,]', '', regex=True).astype(np.int64)
df.abandoned_revenue = df.abandoned_revenue.replace('[\$,]', '', regex=True).astype(np.int64)

df['abandonment_rate'] = df['abandonment_rate'].replace('[\%,]', '', regex=True).astype(np.float64)
df.conversion_rate = df.conversion_rate.replace('[\%,]', '', regex=True).astype(np.float64)
#df.to_csv("analysis/dataConv.csv")

df_out = df.iloc[:, 2:27]
df_out.dtypes
df_out.head(3)
Q1 = df_out.quantile(0.25)
Q3 = df_out.quantile(0.75)
IQR = Q3 - Q1
print(IQR)

print(df_out < (Q1 - 1.5 * IQR)) |(df_out > (Q3 + 1.5 * IQR))

from scipy import stats
df_out[~(np.abs(stats.zscore(df_out)) < 3).all(axis=1)]


df_rev = pd.concat([df.week_start_date, df.revenue], axis=1, ignore_index=True)
df_rev.columns=['date', 'revenue']

df_rev.head()
df_rev.date = pd.to_datetime(df_rev.date, format='%d-%m-%Y')
df_rev.set_index('date', inplace=True)



df_rev[['revenue']].plot()
revenue = df[['revenue']]
revenue.diff().plot()

#from plotly.plotly import plot_mpl


from statsmodels.tsa.seasonal import seasonal_decompose
result = seasonal_decompose(df_rev, model='multiplicative', freq=52)
result.plot()


from statsmodels.tsa.stattools import adfuller
adfuller()




from pyramid.arima import auto_arima
stepwise_model = auto_arima(df_rev, start_p=1, start_q=1,
                           max_p=5, max_q=5, m=12,
                           start_P=0, seasonal=True,
                           d=1, D=1, trace=True,
                           error_action='ignore',  
                           suppress_warnings=True, 
                           stepwise=True)
print(stepwise_model.aic())

train = df_rev.loc['2017-04-01':'2019-02-11']
test = df_rev.loc['2019-02-18':]

stepwise_model.fit(train)
future_forecast = stepwise_model.predict(n_periods=8)

future_forecast = pd.DataFrame(future_forecast,index = test.index,columns=['Prediction'])
pd.concat([test,future_forecast],axis=1).plot()

pd.concat([df_rev,future_forecast],axis=1).plot()


revenue = df[['revenue']]
revenue.rolling(5).mean().plot()



conversion_rate = df[['conversion_rate']]
conversion_rate.rolling(12).mean().plot()

from statsmodels.stats.outliers_influence import variance_inflation_factor    

def calculate_vif(X, thresh=5.0):
    variables = list(range(X.shape[1]))
    print(variables)
    dropped = True
    while dropped:
        dropped = False
        vif = [variance_inflation_factor(X.iloc[:, variables].values, ix)
               for ix in range(X.iloc[:, variables].shape[1])]

        print(vif)
        maxloc = vif.index(max(vif))
        if max(vif) > thresh:
            print('dropping \'' + X.iloc[:, variables].columns[maxloc] +
                  '\' at index: ' + str(maxloc))
            del variables[maxloc]
            dropped = True

    print('Remaining variables:')
    print(X.columns[variables])
    return X.iloc[:, variables]
    
    
calculate_vif(df.iloc[:, 2:24])
df_1 = df.iloc[:, 2:24]


import seaborn as sns
corr = df_1.corr()
corr.to_csv("analysis/corrMatrix.csv")
sns.heatmap(corr)

from sklearn.linear_model import LassoCV
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split


X_rev = df.iloc[:, 1:26]
Y_rev = df.revenue
X_rev_train, X_rev_test, y_rev_train, y_rev_test=train_test_split(X_rev, Y_rev, test_size=0.3, random_state=31)


lasso_rev = LassoCV(cv=5, random_state=0)
lasso_rev.fit(X_rev_train, y_rev_train)
lasso_rev.coef_

train_rev_score=lasso_rev.score(X_rev_train, y_rev_train)
test_rev_score=lasso_rev.score(X_rev_test, y_rev_test)
coeff_rev_used = np.sum(lasso_rev.coef_!=0)
print("Rev training score for alpha=0.0001:", train_rev_score)
print("Rev test score for alpha =0.0001: ", test_rev_score)
print("Rev number of features used: for alpha =0.0001:", coeff_rev_used)


X_conv = df.iloc[:, 2:24]
Y_conv = df.conversion_rate
X_conv_train, X_conv_test, y_conv_train, y_conv_test=train_test_split(X_conv, Y_conv, test_size=0.3, random_state=31)


lasso_conv = LassoCV(cv=5, random_state=0)
lasso_conv.fit(X_rev_train, y_rev_train)
lasso_conv.coef_

train_conv_score=lasso_conv.score(X_rev_train, y_rev_train)
test_conv_score=lasso_conv.score(X_rev_test, y_rev_test)
coeff_conv_used = np.sum(lasso_conv.coef_!=0)
print("Conv training score for alpha=0.0001:", train_conv_score)
print("Conv test score for alpha =0.0001: ", test_conv_score)
print("Conv number of features used: for alpha =0.0001:", coeff_conv_used)



#lr = LinearRegression()
#lr.fit(X_rev_train, y_rev_train)
#
#lr_train_score=lr.score(X_rev_train, y_rev_train)
#lr_test_score=lr.score(X_rev_test, y_rev_test)
#print("LR training score:", lr_train_score)
#print("LR test score: ", lr_test_score)

