# -*- coding: utf-8 -*-
"""
Created on Sat Apr 20 20:27:35 2019

@author: Sanmoy
"""

import os
path="C:\\F\\myProjects\\LTFS"
os.chdir(path)
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

df_ltfs = pd.read_csv("data/train_aox2Jxw/train.csv")
df_ltfs.head(3)
len(df_ltfs.columns)

def convert_intoYrs(df, col):
    for index, row in df.iterrows():
        y=row[col].split(" ")[0]
        y=int(y[0])
        m=row[col].split(" ")[1]
        m=int(m[0])
        yrs = y+(m/12)
        df_ltfs.loc[index, col] = yrs
        
    
convert_intoYrs(df_ltfs, "AVERAGE.ACCT.AGE")
convert_intoYrs(df_ltfs, "CREDIT.HISTORY.LENGTH")

df_ltfs["AVERAGE.ACCT.AGE"]
df_ltfs["CREDIT.HISTORY.LENGTH"]

df_ltfs.to_csv("ltfs.csv", index=False)

df_ltfs = pd.read_csv("ltfs.csv")

df_ltfs["Employment.Type"].value_counts()
df_ltfs["Employment.Type"] = df_ltfs["Employment.Type"].fillna('unemployed')


df_ltfs['Date.of.Birth'] = pd.to_datetime(df_ltfs['Date.of.Birth'], format="%d-%m-%Y")
df_ltfs['DisbursalDate'] = pd.to_datetime(df_ltfs['DisbursalDate'], format="%d-%m-%Y")

df_ltfs['Age'] = round((df_ltfs['DisbursalDate'] - df_ltfs['Date.of.Birth'])/np.timedelta64(1,'Y')).astype(np.int64)
#df_ltfs["Employment.Type"] = df_ltfs["Employment.Type"].replace({'Salaried':0, 'Self employed':1})

#df_ltfs.to_csv("ltfs_1.csv", index=False)


df_ltfs.loc[(df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'A-Very Low Risk') | (df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'B-Very Low Risk') | (df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'C-Very Low Risk') | (df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'D-Very Low Risk') | (df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'E-Low Risk') | (df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'F-Low Risk') | (df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'G-Low Risk'), 'PERFORM_CNS.SCORE.DESCRIPTION'] = "Low_Risk"
df_ltfs.loc[(df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'H-Medium Risk') | (df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'I-Medium Risk'), 'PERFORM_CNS.SCORE.DESCRIPTION'] = "Med_Risk"
df_ltfs.loc[(df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'J-High Risk') | (df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'K-High Risk') | (df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'L-Very High Risk') | (df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'M-Very High Risk'), 'PERFORM_CNS.SCORE.DESCRIPTION'] = "High_Risk"
df_ltfs.loc[(df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'No Bureau History Available') | (df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'Not Scored: Not Enough Info available on the customer') | (df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'Not Scored: No Activity seen on the customer (Inactive)') | (df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'Not Scored: Sufficient History Not Available') | (df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'Not Scored: More than 50 active Accounts found') | (df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] == 'Not Scored: No Updates available in last 36 months') | (df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'] =='Not Scored: Only a Guarantor'), 'PERFORM_CNS.SCORE.DESCRIPTION'] = "Not Available"

#df_ltfs.to_csv("ltfs_2.csv", index=False)


PERFORM_CNS_SCORE_DESCRIPTION = pd.get_dummies(df_ltfs['PERFORM_CNS.SCORE.DESCRIPTION'], drop_first=True)
Employment_Type = pd.get_dummies(df_ltfs['Employment.Type'], drop_first=True)
#df_ltfs["Employment.Type"] = df_ltfs["Employment.Type"].replace({'Low_Risk':0, 'Med_Risk':1, 'High_Risk':2, "Not Available":3})
df_ltfs_1 = df_ltfs

df_ltfs_1.drop(['UniqueID', 'branch_id','supplier_id','manufacturer_id','Current_pincode_ID','Date.of.Birth', 'DisbursalDate', 'Employee_code_ID', 'PERFORM_CNS.SCORE.DESCRIPTION', 'Employment.Type'], 1, inplace=True)
df_ltfs_dmy = pd.concat([df_ltfs_1, Employment_Type, PERFORM_CNS_SCORE_DESCRIPTION], axis=1)
df_ltfs_dmy.info()

#df_ltfs_dmy.to_csv("ltfs_3.csv", index=False)

#from sklearn.preprocessing import StandardScaler
#df_ltfs_dmy[['disbursed_amount', 'asset_cost', 'ltv', 'PERFORM_CNS.SCORE', 'PRI.CURRENT.BALANCE', 'PRI.SANCTIONED.AMOUNT', 'PRI.DISBURSED.AMOUNT', 'PRIMARY.INSTAL.AMT']] = StandardScaler().fit_transform(df_ltfs_dmy[['disbursed_amount', 'asset_cost', 'ltv', 'PERFORM_CNS.SCORE', 'PRI.CURRENT.BALANCE', 'PRI.SANCTIONED.AMOUNT', 'PRI.DISBURSED.AMOUNT', 'PRIMARY.INSTAL.AMT']])
#df_ltfs_dmy.to_csv("ltfs_4.csv", index=False)

cols = list(df_ltfs_dmy)
cols.insert(0, cols.pop(cols.index('loan_default')))
df_ltfs_dmy1 = df_ltfs_dmy.loc[:, cols]

df_ltfs_dmy1["loan_default"].value_counts()
#df_ltfs_dmy1.to_csv("ltfs_5.csv", index=False)

#len(df_ltfs_dmy1.columns)

from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, auc, roc_auc_score

df_ltfs_dmy1["AVERAGE.ACCT.AGE"] = df_ltfs_dmy1["AVERAGE.ACCT.AGE"].astype(np.float64)
df_ltfs_dmy1["CREDIT.HISTORY.LENGTH"] = df_ltfs_dmy1["CREDIT.HISTORY.LENGTH"].astype(np.float64)

X = df_ltfs_dmy1.iloc[:, 1:37]
Y = df_ltfs_dmy1.loan_default
X_train, X_test, y_train, y_test=train_test_split(X, Y, test_size=0.2, random_state=31)




from sklearn.model_selection import GridSearchCV
param_test1 = {
    'max_depth':range(3,10,2),
    'min_child_weight':range(1,6,2),
    'learning_rate':[i/1000.0 for i in range(5,20,2)],
    'subsample':[i/100.0 for i in range(55,70,5)],
    'colsample_bytree':[i/100.0 for i in range(85,100,5)]
    
}
gsearch1 = GridSearchCV(estimator = XGBClassifier( learning_rate =0.1, 
                                                  n_estimators=1000, 
                                                  max_depth=5,
                                                  min_child_weight=1,
                                                  gamma=0, 
                                                  subsample=0.8, 
                                                  colsample_bytree=0.8,
                                                  objective= 'binary:logistic', nthread=4, scale_pos_weight=1, seed=27), 
                        param_grid = param_test1, 
                        scoring='roc_auc',
                        n_jobs=4,
                        iid=False, 
                        cv=5)

gsearch1.fit(X_train, y_train)
gsearch1.grid_scores_, gsearch1.best_params_, gsearch1.best_score_




# fit model no training data
model = XGBClassifier(objective="binary:logistic", random_state=42, eval_metric="auc", 
                      learning_rate =0.1, n_estimators=1000,
    max_depth=5, min_child_weight=1, gamma=0,subsample=0.8,colsample_bytree=0.8,
    nthread=4,scale_pos_weight=1)
model.fit(X_train, y_train, early_stopping_rounds=2, eval_set=[(X_test, y_test)])


# make predictions for test data
y_pred = model.predict(X_test)
#predictions = [round(value) for value in y_pred]

accuracy_score(y_test, y_pred)
roc_auc_score(y_test, y_pred)





