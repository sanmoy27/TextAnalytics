####Team BLUE
cat("\014")
getwd()
setwd("C:\\F\\NMIMS\\DataScience\\hackathon_2\\MobilePriceClassification")
library(dplyr)
library(tidyr)
library(stringr)
library(caTools)
library(ISLR)
library(glmnet)
library(caret)
library(class)
library(car)
library(ggpubr)
library(e1071)

mobile_hck <- read.csv("train.csv", stringsAsFactors = FALSE, header = TRUE)
dim(mobile_hck)
str(mobile_hck)
head(mobile_hck)

##Exploratory data Analysis
summary(mobile_hck)

#######Data Cleaning
hist(mobile_hck$battery_power, breaks=12, 
     main="Histogram of Battery", 
     xlab="Battery_Power", ylab="Freq Count")

hist(mobile_hck$clock_speed)
hist(mobile_hck$fc)
hist(mobile_hck$int_memory)
hist(mobile_hck$m_dep)
hist(mobile_hck$clock_speed)
hist(mobile_hck$mobile_wt)
hist(mobile_hck$m_dep)
hist(mobile_hck$n_cores)
hist(mobile_hck$mobile_wt)
hist(mobile_hck$pc)
hist(mobile_hck$px_height)
hist(mobile_hck$px_width)
hist(mobile_hck$ram)
hist(mobile_hck$sc_h)
hist(mobile_hck$sc_w)
hist(mobile_hck$talk_time)


cat("\014")
#Detect NAs
detectNAs<-function(x){
  return(sum(is.na(x)))
}
sapply(mobile_hck, detectNAs)



#Detect Class
detectClass<-function(x){
  return(class(x))
}
sapply(mobile_hck, detectClass)


#DetectOutlier
detectOulier<- function(x){
  if(class(x)=="numeric" | class(x)=="integer"){
    q1 <- quantile(x, 0.25, na.rm = FALSE)
    q3 <- quantile(x, 0.75, na.rm = FALSE)
    maxLimit <- 1.5*IQR(x, na.rm = FALSE)
    maxLimit
    
    x[x<(q1[1]-maxLimit)] <- NA
    x[x>(q3[2]+maxLimit)] <- NA
    
    return(x[is.na(x)])
  }else{
    return("Not a Numeric")
  }
  
}
sapply(mobile_hck, detectOulier)




######### Model Selection
#Defining the training controls for multiple models
fitControl <- trainControl( method = "repeatedcv",  number = 10,   savePredictions = 'final',  classProbs = T)

### Fitting knn
cat("\014")
data_knn <- mobile_hck

data_knn$price_range[data_knn$price_range==0] <- "a"
data_knn$price_range[data_knn$price_range==1] <- "b"
data_knn$price_range[data_knn$price_range==2] <- "c"
data_knn$price_range[data_knn$price_range==3] <- "d"
data_knn$price_range = factor(data_knn$price_range)


#$battery_power <- as.numeric(data_knn$battery_power)
#data_knn$blue <- as.numeric(data_knn$blue)
#data_knn$clock_speed <- as.numeric(data_knn$clock_speed)
#data_knn$fc <- as.numeric(data_knn$fc)
#data_knn$four_g <- as.numeric(data_knn$four_g)
#data_knn$battery_power <- as.numeric(data_knn$battery_power)

id = 1:20 
data_knn[id] = data.matrix(data_knn[id])
sapply(data_knn, class)

#data_knn[id] = as.numeric(unlist(data_knn[id]))
str(data_knn)

set.seed(100) # set seed to replicate results
split<-sample.split(data_knn$price_range, SplitRatio=0.8)
trainSet<-subset(data_knn, split==TRUE)
testSet<-subset(data_knn, split==FALSE)

str(trainSet)

model_knn<-train(price_range~(ram+battery_power+px_width+px_height+talk_time+mobile_wt+pc+fc),data=trainSet,method='knn', trControl=fitControl, tuneLength=3)

#Predicting using knn model
pred_knn<-predict(model_knn, testSet)

#Checking the accuracy of the knn model
confusionMatrix(testSet$price_range,pred_knn)##Accuracy=91.75%

##In order to do feature selection and find out most important independent variables
varImp(model_knn)

###########################################
data_o <- mobile_hck
data_o$blue[data_o$blue==0] <- "No"
data_o$blue[data_o$blue==1] <- "Yes"
data_o$blue = factor(data_o$blue)

data_o$dual_sim[data_o$dual_sim==0] <- "No"
data_o$dual_sim[data_o$dual_sim==1] <- "Yes"
data_o$dual_sim = factor(data_o$dual_sim)

data_o$four_g[data_o$four_g==0] <- "No"
data_o$four_g[data_o$four_g==1] <- "Yes"
data_o$four_g = factor(data_o$four_g)


data_o$three_g[data_o$three_g==0] <- "No"
data_o$three_g[data_o$three_g==1] <- "Yes"
data_o$three_g = factor(data_o$three_g)

data_o$touch_screen[data_o$touch_screen==0] <- "No"
data_o$touch_screen[data_o$touch_screen==1] <- "Yes"
data_o$touch_screen = factor(data_o$touch_screen)

data_o$wifi[data_o$wifi==0] <- "No"
data_o$wifi[data_o$wifi==1] <- "Yes"
data_o$wifi = factor(data_o$wifi)

data_o$price_range[data_o$price_range==0] <- "a"
data_o$price_range[data_o$price_range==1] <- "b"
data_o$price_range[data_o$price_range==2] <- "c"
data_o$price_range[data_o$price_range==3] <- "d"
data_o$price_range = factor(data_o$price_range)

# data_o$battery_power <- scale(data_o$battery_power)
# data_o$clock_speed <- scale(data_o$clock_speed)
# data_o$fc <- scale(data_o$fc)
# data_o$int_memory <- scale(data_o$int_memory)
# data_o$mobile_wt <- scale(data_o$battery_power)
# data_o$n_cores <- scale(data_o$n_cores)
# data_o$pc <- scale(data_o$pc)
# data_o$px_height <- scale(data_o$px_height)
# data_o$px_width <- scale(data_o$px_width)
# data_o$ram <- scale(data_o$ram)
# data_o$sc_h <- scale(data_o$sc_h)
# data_o$sc_w <- scale(data_o$sc_w)
# data_o$talk_time <- scale(data_o$talk_time)

cat("\014")
set.seed(100) # set seed to replicate results
split<-sample.split(data_o$price_range, SplitRatio=0.8)
trainSet_o<-subset(data_o, split==TRUE)
testSet_o<-subset(data_o, split==FALSE)
dim(trainSet_o)
dim(testSet_o)

##Fitting Random Forest Model
model_rf<-train(price_range~(ram+battery_power+px_width+px_height+talk_time+mobile_wt+pc+fc),data=trainSet_o,method='rf', trControl=fitControl, tuneLength=3)

#Predicting using Random Forest model
pred_rf<-predict(model_rf, testSet_o)

#Checking the accuracy of the rf model
confusionMatrix(testSet_o$price_range,pred_rf)##Accuracy=90.25%

##In order to do feature selection and find out most important independent variables
varImp(model_rf)


##Fitting SVM Model
 # tune.out_svm_mobile=tune(svm ,price_range ~(ram+battery_power+px_width+px_height+talk_time+mobile_wt+pc+fc), data = trainSet_o ,kernel ="linear",ranges =list(cost=c(0.001 , 0.01, 0.1, 1,5,10,100)))
 # pred_svm=predict (tune.out_svm_mobile$best.model, newdata=testSet_o)
 # confusionMatrix(testSet_o$price_range,pred_svm)

  # svm.tune <- tune.svm(price_range ~., data = trainSet_o, 
  #                      gamma = 10^(-3:0), cost = 10^(-1:1));
  # svm.model <- svm(price_range ~(ram+battery_power+px_width+px_height+talk_time+mobile_wt+pc+fc), data = trainSet_o, 
  #                  kernel = "linear", 
  #                  gamma = svm.tune$best.parameters$gamma, 
  #                  cost  = svm.tune$best.parameters$cost);
  # 
  # pred_svm=predict (svm.model, newdata=testSet_o)
  # confusionMatrix(testSet_o$price_range,pred_svm)


model_svm <- train(price_range ~., data = trainSet_o, method = "svmLinear",
                    trControl=fitControl,
                    preProcess = c("center", "scale"),
                    tuneLength = 10,
                   ranges =list(cost=c(0.001, 0.01, 0.1, 1,5, 10, 100)), gamma=0.5)

#Predicting using SVM model
pred_svm<-predict(model_svm, testSet_o)

#Checking the accuracy of the SVM model
confusionMatrix(testSet_o$price_range,pred_svm) ##Accuracy=96.75%

##In order to do feature selection and find out most important independent variables
varImp(model_svm)



model_svm <- train(price_range ~ (ram+battery_power+px_width+px_height+mobile_wt+pc+fc), data = trainSet_o, method = "svmLinear",
                   trControl=fitControl,
                   tuneLength = 10,
                   gamma = 10^(-3:0), cost = 10^(-1:1))

#Predicting using SVM model
pred_svm<-predict(model_svm, testSet_o)

#Checking the accuracy of the SVM model
confusionMatrix(testSet_o$price_range,pred_svm) ##Accuracy=97.75%


### Prediction in Test Set
cat("\014")
mobile_hck_test <- read.csv("test.csv", stringsAsFactors = FALSE, header = TRUE)
dim(mobile_hck_test)
str(mobile_hck_test)
head(mobile_hck_test)

mobile_hck_test_knn <- mobile_hck_test[,-1]
head(mobile_hck_test_knn)
dim(mobile_hck_test_knn)

###Data preparation for fitting KNN Model
id_test = 1:20 # column ids to change
mobile_hck_test_knn[id_test] = data.matrix(mobile_hck_test_knn[id_test])
sapply(mobile_hck_test_knn, class)
str(mobile_hck_test_knn)

##Prediction using KNN Model
test_pred_knn <- predict(model_knn, mobile_hck_test_knn)

mobile_data_knn <- data.frame(id=mobile_hck_test$id, price_range=test_pred_knn)
mobile_data_knn$price_range <- as.character(mobile_data_knn$price_range)
mobile_data_knn$price_range[mobile_data_knn$price_range=="a"] <- 0
mobile_data_knn$price_range[mobile_data_knn$price_range=="b"] <- 1
mobile_data_knn$price_range[mobile_data_knn$price_range=="c"] <- 2
mobile_data_knn$price_range[mobile_data_knn$price_range=="d"] <- 3
write.table(mobile_data_knn, file = 'sample_knn.csv', sep=",", row.names=FALSE,col.names=TRUE)


cat("\014")
######Preparing the test data for fitting Random Forest and SVM model prediction
mobile_hck_test_o <- mobile_hck_test[,-1]
head(mobile_hck_test_o)
dim(mobile_hck_test_o)

mobile_hck_test_o$blue[mobile_hck_test_o$blue==0] <- "No"
mobile_hck_test_o$blue[mobile_hck_test_o$blue==1] <- "Yes"
mobile_hck_test_o$blue = factor(mobile_hck_test_o$blue)

mobile_hck_test_o$dual_sim[mobile_hck_test_o$dual_sim==0] <- "No"
mobile_hck_test_o$dual_sim[mobile_hck_test_o$dual_sim==1] <- "Yes"
mobile_hck_test_o$dual_sim = factor(mobile_hck_test_o$dual_sim)

mobile_hck_test_o$four_g[mobile_hck_test_o$four_g==0] <- "No"
mobile_hck_test_o$four_g[mobile_hck_test_o$four_g==1] <- "Yes"
mobile_hck_test_o$four_g = factor(mobile_hck_test_o$four_g)

mobile_hck_test_o$three_g[mobile_hck_test_o$three_g==0] <- "No"
mobile_hck_test_o$three_g[mobile_hck_test_o$three_g==1] <- "Yes"
mobile_hck_test_o$three_g = factor(mobile_hck_test_o$three_g)

mobile_hck_test_o$touch_screen[mobile_hck_test_o$touch_screen==0] <- "No"
mobile_hck_test_o$touch_screen[mobile_hck_test_o$touch_screen==1] <- "Yes"
mobile_hck_test_o$touch_screen = factor(mobile_hck_test_o$touch_screen)

mobile_hck_test_o$wifi[mobile_hck_test_o$wifi==0] <- "No"
mobile_hck_test_o$wifi[mobile_hck_test_o$wifi==1] <- "Yes"
mobile_hck_test_o$wifi = factor(mobile_hck_test_o$wifi)


##Prediction using Support Vector Model
test_pred_svm <- predict(model_svm, mobile_hck_test_o)
mobile_data_svm <- data.frame(id=mobile_hck_test$id, price_range=test_pred_svm)
mobile_data_svm$price_range <- as.character(mobile_data_svm$price_range)
mobile_data_svm$price_range[mobile_data_svm$price_range=="a"] <- 0
mobile_data_svm$price_range[mobile_data_svm$price_range=="b"] <- 1
mobile_data_svm$price_range[mobile_data_svm$price_range=="c"] <- 2
mobile_data_svm$price_range[mobile_data_svm$price_range=="d"] <- 3
write.table(mobile_data_svm, file = 'sample_svm_1.csv', sep=",", row.names=FALSE,col.names=TRUE)

##Prediction using Random Forest Model
test_pred_rf <- predict(model_rf, mobile_hck_test_o)
mobile_data_rf <- data.frame(id=mobile_hck_test$id, price_range=test_pred_rf)
mobile_data_rf$price_range <- as.character(mobile_data_rf$price_range)
mobile_data_rf$price_range[mobile_data_rf$price_range=="a"] <- 0
mobile_data_rf$price_range[mobile_data_rf$price_range=="b"] <- 1
mobile_data_rf$price_range[mobile_data_rf$price_range=="c"] <- 2
mobile_data_rf$price_range[mobile_data_rf$price_range=="d"] <- 3
write.table(mobile_data_rf, file = 'sample_rf.csv', sep=",", row.names=FALSE,col.names=TRUE)


####At the end we took SVM as our final model for prediction of test set.

