# -*- coding: utf-8 -*-
"""
Created on Thu Sep 20 01:40:39 2018

@author: Sanmoy
"""

import os
import pandas as pd
import numpy as np
import seaborn as sb

import keras
from keras.models import Sequential
from keras.layers import Dense, Dropout, BatchNormalization
from keras.wrappers.scikit_learn import KerasClassifier
from keras.utils import np_utils
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
from sklearn.preprocessing import LabelEncoder
from sklearn.pipeline import Pipeline

path="C:\\F\\NMIMS\\DataScience\\hackathon_2\\MobilePriceClassification"
os.chdir(path)

##Read CSV
mobile_data = pd.read_csv("train.csv")
mobile_data.info()
mobile_data.describe()
mobile_data.head(3)
mobile_data.tail(3)
mobile_data.isnull().sum()


X=mobile_data.iloc[:, 0:20].values
y=mobile_data.iloc[:, 20].values

# encode class values as integers

#Splitting into train and test
from sklearn.cross_validation import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)

# Standardising
from sklearn.preprocessing import StandardScaler
sc_X = StandardScaler()
X_train = sc_X.fit_transform(X_train)
X_test = sc_X.transform(X_test)


dummy_y = np_utils.to_categorical(y_train)

# fix random seed for reproducibility
seed = 7
np.random.seed(seed)

def baseline_model():
    classifier = Sequential()
    
    #Adding first hidden layer
    classifier.add(Dense(units=10, kernel_initializer='uniform', activation='relu', input_dim=20))
    #classifier.add(Dropout(0.2))
    classifier.add(BatchNormalization())
    #Adding second hidden layer
    classifier.add(Dense(units=10, kernel_initializer='uniform', activation='relu'))
    #classifier.add(Dropout(0.1))
    classifier.add(BatchNormalization())
    #Adding output layer
    classifier.add(Dense(units=4, kernel_initializer='uniform', activation='softmax'))
    
    #Compile, #adam is stochastic gradient algorithm
    classifier.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    return classifier
#Fit the model on traiing set
estimator = KerasClassifier(build_fn=baseline_model, epochs=200, batch_size=5, verbose=0)

kfold = KFold(n_splits=10, shuffle=True, random_state=seed)

results = cross_val_score(estimator, X_train, dummy_y, cv=kfold)
print("Baseline: %.2f%% (%.2f%%)" % (results.mean()*100, results.std()*100))


y_fit = estimator.fit(X_train, y_train)
y_pred = estimator.predict(X_test)
y_pred

# Making the Confusion Matrix
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred)
print(cm)

test_data = pd.read_csv("test.csv")
test_data.info()
test_data_dmmy = test_data.drop('id', 1).values
test_data_dmmy = sc_X.fit_transform(test_data_dmmy)

y_test_pred = estimator.predict(test_data_dmmy)
y_test_pred

columns = ['id','price_range']
test_data_df = pd.DataFrame(test_data.iloc[:,0].values)
df_test_pred = pd.DataFrame(y_test_pred, columns=[''])
result_df = pd.concat([test_data_df, df_test_pred], axis=1)
result_df.to_csv("sample_NN.csv", index=False, header=columns)
