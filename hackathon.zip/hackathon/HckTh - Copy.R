getwd()
setwd("C:/F/NMIMS/DataScience/hackathon/data")
library(dplyr)
library(tidyr)
library(stringr)
library(caTools)
library(ISLR)
library(glmnet)
library(caret)
library(class)
library(FactoMineR)
library(car)

data_hck <- read.csv("A.csv", stringsAsFactors = FALSE, header = TRUE)
head(data_hck)
tail(data_hck)
dim(data_hck)
data_hck_dmm_1 <- select(data_hck, loan_amnt,funded_amnt,funded_amnt_inv,term,int_rate,installment,grade,sub_grade,emp_title,emp_length,home_ownership,annual_inc,verification_status,issue_d,pymnt_plan,zip_code,addr_state,dti,delinq_2yrs,earliest_cr_line,inq_last_6mths,mths_since_last_delinq,mths_since_last_record,open_acc,pub_rec,revol_bal,revol_util,total_acc,initial_list_status,total_pymnt,total_pymnt_inv,total_rec_prncp,total_rec_int,total_rec_late_fee,recoveries,collection_recovery_fee,last_pymnt_d,last_pymnt_amnt,next_pymnt_d,acc_now_delinq,delinq_amnt,pub_rec_bankruptcies,tax_liens,debt_settlement_flag,debt_settlement_flag_date,settlement_status,settlement_date,settlement_amount,settlement_percentage,settlement_term,default_flag)
dim(data_hck_dmm_1)


cat("\014")
#Detect NAs
detectNAs<-function(x){
  return(sum(is.na(x)))
}
sapply(data_hck_dmm_1, detectNAs)



##Clean delinq_2yrs
summarise(group_by(data_hck_dmm_1, delinq_2yrs), n())
data_hck_dmm_1$delinq_2yrs[is.na(data_hck_dmm_1$delinq_2yrs)] <- 0
class(data_hck_dmm_1$delinq_2yrs)

#clean inq_last_6mths
summarise(group_by(data_hck_dmm_1, inq_last_6mths), n())
data_hck_dmm_1$inq_last_6mths[is.na(data_hck_dmm_1$inq_last_6mths)] <- 0
class(data_hck_dmm_1$inq_last_6mths)

#clean annual_inc
data_hck_dmm_1$annual_inc[is.na(data_hck_dmm_1$annual_inc)] <- median(data_hck_dmm_1$annual_inc, na.rm=TRUE)
class(data_hck_dmm_1$annual_inc)

#clean open_acc
summarise(group_by(data_hck_dmm_1, open_acc), n())
data_hck_dmm_1 %>% 
  count(open_acc) %>%
  arrange(desc(n)) %>% 
  group_by(open_acc)

data_hck_dmm_1$open_acc[is.na(data_hck_dmm_1$open_acc)] <- 6

#clean pub_rec
summarise(group_by(data_hck_dmm_1, pub_rec), n())
data_hck_dmm_1$pub_rec[is.na(data_hck_dmm_1$pub_rec)] <- 0


#clean total_acc
summarise(group_by(data_hck_dmm_1, total_acc), n())
data_hck_dmm_1 %>% 
  count(total_acc) %>%
  arrange(desc(n)) %>% 
  group_by(total_acc)

data_hck_dmm_1$total_acc[is.na(data_hck_dmm_1$total_acc)] <- 16


#clean delinq_amnt
summarise(group_by(data_hck_dmm_1, delinq_amnt), n())
data_hck_dmm_1$delinq_amnt[is.na(data_hck_dmm_1$delinq_amnt)] <- 0

#clean acc_now_delinq
summarise(group_by(data_hck_dmm_1, acc_now_delinq), n())
data_hck_dmm_1$acc_now_delinq[is.na(data_hck_dmm_1$acc_now_delinq)] <- 0


#clean pub_rec_bankruptcies
summarise(group_by(data_hck_dmm_1, pub_rec_bankruptcies), n())
data_hck_dmm_1$pub_rec_bankruptcies[is.na(data_hck_dmm_1$pub_rec_bankruptcies)] <- 0

#clean tax_liens
summarise(group_by(data_hck_dmm_1, tax_liens), n())
data_hck_dmm_1$tax_liens[is.na(data_hck_dmm_1$tax_liens)] <- 0



#clean mths_since_last_delinq
summarise(group_by(data_hck_dmm_1, mths_since_last_delinq), n())
data_hck_dmm_1 %>% 
  count(mths_since_last_delinq) %>%
  arrange(desc(n)) %>% 
  group_by(mths_since_last_delinq)

data_hck_dmm_1$mths_since_last_delinq[is.na(data_hck_dmm_1$mths_since_last_delinq)] <- 0

dim(data_hck_dmm_1)
data_hck_dmm_2<-select(data_hck_dmm_1, -mths_since_last_record, -settlement_amount, -settlement_percentage, -settlement_term, -settlement_status, -settlement_date, -debt_settlement_flag_date, -emp_title, -zip_code, -addr_state, -earliest_cr_line, -last_pymnt_d, -earliest_cr_line, -issue_d, -initial_list_status, -pymnt_plan, -next_pymnt_d, -delinq_amnt, -tax_liens, -sub_grade)
dim(data_hck_dmm_2)
head(data_hck_dmm_2)

summarise(group_by(data_hck_dmm_2, term), n())
data_hck_dmm_2$term <- as.character(str_trim(data_hck_dmm_2$term))
data_hck_dmm_2$term[data_hck_dmm_2$term=="36 months"] <- 0
data_hck_dmm_2$term[data_hck_dmm_2$term=="60 months"] <- 1
data_hck_dmm_2$term <- as.numeric(data_hck_dmm_2$term)

summarise(group_by(data_hck_dmm_2, grade), n())
data_hck_dmm_2$grade[data_hck_dmm_2$grade=="A"] <- 1
data_hck_dmm_2$grade[data_hck_dmm_2$grade=="B"] <- 2
data_hck_dmm_2$grade[data_hck_dmm_2$grade=="C"] <- 3
data_hck_dmm_2$grade[data_hck_dmm_2$grade=="D"] <- 4
data_hck_dmm_2$grade[data_hck_dmm_2$grade=="E"] <- 5
data_hck_dmm_2$grade[data_hck_dmm_2$grade=="F"] <- 6
data_hck_dmm_2$grade[data_hck_dmm_2$grade=="G"] <- 7
data_hck_dmm_2$grade <- as.numeric(data_hck_dmm_2$grade)

data_hck_dmm_2$int_rate <- as.numeric(substr(data_hck_dmm_2$int_rate, 1, nchar(data_hck_dmm_2$int_rate)-1))

summarise(group_by(data_hck_dmm_2, home_ownership), n())
data_hck_dmm_2$home_ownership[data_hck_dmm_2$home_ownership=="MORTGAGE"] <- 1
data_hck_dmm_2$home_ownership[data_hck_dmm_2$home_ownership=="OWN"] <- 2
data_hck_dmm_2$home_ownership[data_hck_dmm_2$home_ownership=="RENT"] <- 3
data_hck_dmm_2$home_ownership[data_hck_dmm_2$home_ownership=="NONE"] <- 4
data_hck_dmm_2$home_ownership[data_hck_dmm_2$home_ownership=="OTHER"] <- 5
data_hck_dmm_2$home_ownership <- as.numeric(data_hck_dmm_2$home_ownership)



#clean emp_length
summarise(group_by(data_hck_dmm_2, emp_length), n())
class(data_hck_dmm_2$emp_length)
data_hck_dmm_2$emp_length[data_hck_dmm_2$emp_length=="n/a"]<-"< 1 year"
data_hck_dmm_2$emp_length[str_trim(data_hck_dmm_2$emp_length)=="< 1 year"] <- 0
data_hck_dmm_2$emp_length[str_trim(data_hck_dmm_2$emp_length)=="1 year"] <- 1
data_hck_dmm_2$emp_length[str_trim(data_hck_dmm_2$emp_length)=="10+ years"] <- 2
data_hck_dmm_2$emp_length[str_trim(data_hck_dmm_2$emp_length)=="2 years"] <- 3
data_hck_dmm_2$emp_length[str_trim(data_hck_dmm_2$emp_length)=="3 years"] <- 4
data_hck_dmm_2$emp_length[str_trim(data_hck_dmm_2$emp_length)=="4 years"] <- 5
data_hck_dmm_2$emp_length[str_trim(data_hck_dmm_2$emp_length)=="5 years"] <- 6
data_hck_dmm_2$emp_length[str_trim(data_hck_dmm_2$emp_length)=="6 years"] <- 7
data_hck_dmm_2$emp_length[str_trim(data_hck_dmm_2$emp_length)=="7 years"] <- 8
data_hck_dmm_2$emp_length[str_trim(data_hck_dmm_2$emp_length)=="8 years"] <-9
data_hck_dmm_2$emp_length[str_trim(data_hck_dmm_2$emp_length)=="9 years"] <-10
class(data_hck_dmm_2$emp_length)
data_hck_dmm_2$emp_length<-as.numeric(data_hck_dmm_2$emp_length)


summarise(group_by(data_hck_dmm_2, verification_status), n())
class(data_hck_dmm_2$verification_status)
data_hck_dmm_2$verification_status[data_hck_dmm_2$verification_status=="Not Verified"] <- 0
data_hck_dmm_2$verification_status[data_hck_dmm_2$verification_status=="Source Verified"] <- 1
data_hck_dmm_2$verification_status[data_hck_dmm_2$verification_status=="Verified"] <- 2
data_hck_dmm_2$verification_status<-as.numeric(data_hck_dmm_2$verification_status)


summarise(group_by(data_hck_dmm_2, revol_util), n())
class(data_hck_dmm_2$revol_util)
data_hck_dmm_2$revol_util[str_trim(data_hck_dmm_2$revol_util)==""] <- "0%"
data_hck_dmm_2$revol_util <- as.numeric(substr(data_hck_dmm_2$revol_util, 1, nchar(data_hck_dmm_2$revol_util)-1))

summarise(group_by(data_hck_dmm_2, debt_settlement_flag), n())
data_hck_dmm_2$debt_settlement_flag[str_trim(data_hck_dmm_2$debt_settlement_flag)=="N"] <- 0
data_hck_dmm_2$debt_settlement_flag[str_trim(data_hck_dmm_2$debt_settlement_flag)=="Y"] <- 1
data_hck_dmm_2$debt_settlement_flag<-as.numeric(data_hck_dmm_2$debt_settlement_flag)
class(data_hck_dmm_2$debt_settlement_flag)

str(data_hck_dmm_2)
dim(data_hck_dmm_2)

sapply(data_hck_dmm_2, detectNAs)
cat("\014")
#Detect Space
detectSpace<-function(x){
  return(sum(is.na(str_trim(x)=="")))
}
sapply(data_hck_dmm_2, detectSpace)

str(data_hck_dmm_2)
dim(data_hck_dmm_2)
data_hck_dmm_2 <- scale(data_hck_dmm_2[, -32])
head(data_hck_dmm_2)
class(data_hck_dmm_2)

x=data_hck_dmm_2
y=data_hck_dmm_1$default_flag
set.seed(1)
train=sample(1:nrow(x), nrow(x)/2)
test=(-train)


log.model <- cv.glmnet(x[train,], y[train], alpha=1, family = "binomial")
#log.model <- glm(income ~ ., data=trainSet, family = binomial())
summary(log.model)

log.model$lambda.min
plot(log.model)


cat("\014")
predicted <- predict(log.model, newx=x[test,], s="lambda.min", type="response")
#pred_flag <- ifelse(predicted>0.5, 1, 0)

model.coeff <- predict(log.model, newx=x[test,], s="lambda.min", type="coefficients")[1:31,]
model.coeff[model.coeff!=0]
conf<-table(pred_flag, actuals=y[test])
conf

tab<-table(predicted>0.15, y[test])
dimnames(tab)[[1]] = c(0,1)
confusionMatrix(tab)


#####################################Test ###############################################
data_hck_test <- read.csv("B.csv", stringsAsFactors = FALSE, header = TRUE)
head(data_hck_test)
tail(data_hck_test)
dim(data_hck_test)
data_hck_test_dmm_1 <- select(data_hck_test, loan_amnt,funded_amnt,funded_amnt_inv,term,int_rate,installment,grade,sub_grade,emp_title,emp_length,home_ownership,annual_inc,verification_status,issue_d,pymnt_plan,zip_code,addr_state,dti,delinq_2yrs,earliest_cr_line,inq_last_6mths,mths_since_last_delinq,mths_since_last_record,open_acc,pub_rec,revol_bal,revol_util,total_acc,initial_list_status,total_pymnt,total_pymnt_inv,total_rec_prncp,total_rec_int,total_rec_late_fee,recoveries,collection_recovery_fee,last_pymnt_d,last_pymnt_amnt,next_pymnt_d,acc_now_delinq,delinq_amnt,pub_rec_bankruptcies,tax_liens,debt_settlement_flag,debt_settlement_flag_date,settlement_status,settlement_date,settlement_amount,settlement_percentage,settlement_term)
dim(data_hck_test_dmm_1)


cat("\014")
#Detect NAs
detectNAs<-function(x){
  return(sum(is.na(x)))
}
sapply(data_hck_test_dmm_1, detectNAs)



##Clean delinq_2yrs
summarise(group_by(data_hck_test_dmm_1, delinq_2yrs), n())
data_hck_test_dmm_1$delinq_2yrs[is.na(data_hck_test_dmm_1$delinq_2yrs)] <- 0
class(data_hck_test_dmm_1$delinq_2yrs)

#clean inq_last_6mths
summarise(group_by(data_hck_test_dmm_1, inq_last_6mths), n())
data_hck_test_dmm_1$inq_last_6mths[is.na(data_hck_test_dmm_1$inq_last_6mths)] <- 0
class(data_hck_test_dmm_1$inq_last_6mths)

#clean annual_inc
data_hck_test_dmm_1$annual_inc[is.na(data_hck_test_dmm_1$annual_inc)] <- median(data_hck_test_dmm_1$annual_inc, na.rm=TRUE)
class(data_hck_test_dmm_1$annual_inc)

#clean open_acc
summarise(group_by(data_hck_test_dmm_1, open_acc), n())
data_hck_test_dmm_1 %>% 
  count(open_acc) %>%
  arrange(desc(n)) %>% 
  group_by(open_acc)

data_hck_test_dmm_1$open_acc[is.na(data_hck_test_dmm_1$open_acc)] <- 6

#clean pub_rec
summarise(group_by(data_hck_test_dmm_1, pub_rec), n())
data_hck_test_dmm_1$pub_rec[is.na(data_hck_test_dmm_1$pub_rec)] <- 0


#clean total_acc
summarise(group_by(data_hck_test_dmm_1, total_acc), n())
data_hck_test_dmm_1 %>% 
  count(total_acc) %>%
  arrange(desc(n)) %>% 
  group_by(total_acc)

data_hck_test_dmm_1$total_acc[is.na(data_hck_test_dmm_1$total_acc)] <- 16


#clean delinq_amnt
summarise(group_by(data_hck_test_dmm_1, delinq_amnt), n())
data_hck_test_dmm_1$delinq_amnt[is.na(data_hck_test_dmm_1$delinq_amnt)] <- 0

#clean acc_now_delinq
summarise(group_by(data_hck_test_dmm_1, acc_now_delinq), n())
data_hck_test_dmm_1$acc_now_delinq[is.na(data_hck_test_dmm_1$acc_now_delinq)] <- 0


#clean pub_rec_bankruptcies
summarise(group_by(data_hck_test_dmm_1, pub_rec_bankruptcies), n())
data_hck_test_dmm_1$pub_rec_bankruptcies[is.na(data_hck_test_dmm_1$pub_rec_bankruptcies)] <- 0

#clean tax_liens
summarise(group_by(data_hck_test_dmm_1, tax_liens), n())
data_hck_test_dmm_1$tax_liens[is.na(data_hck_test_dmm_1$tax_liens)] <- 0



#clean mths_since_last_delinq
summarise(group_by(data_hck_test_dmm_1, mths_since_last_delinq), n())
data_hck_test_dmm_1 %>% 
  count(mths_since_last_delinq) %>%
  arrange(desc(n)) %>% 
  group_by(mths_since_last_delinq)

data_hck_test_dmm_1$mths_since_last_delinq[is.na(data_hck_test_dmm_1$mths_since_last_delinq)] <- 0

dim(data_hck_test_dmm_1)
data_hck_test_dmm_2<-select(data_hck_test_dmm_1, -mths_since_last_record, -settlement_amount, -settlement_percentage, -settlement_term, -settlement_status, -settlement_date, -debt_settlement_flag_date, -emp_title, -zip_code, -addr_state, -earliest_cr_line, -last_pymnt_d, -earliest_cr_line, -issue_d, -initial_list_status, -pymnt_plan, -next_pymnt_d, -delinq_amnt, -tax_liens, -sub_grade)
dim(data_hck_test_dmm_2)
head(data_hck_test_dmm_2)

summarise(group_by(data_hck_test_dmm_2, term), n())
data_hck_test_dmm_2$term <- as.character(str_trim(data_hck_test_dmm_2$term))
data_hck_test_dmm_2$term[data_hck_test_dmm_2$term=="36 months"] <- 0
data_hck_test_dmm_2$term[data_hck_test_dmm_2$term=="60 months"] <- 1
data_hck_test_dmm_2$term <- as.numeric(data_hck_test_dmm_2$term)

summarise(group_by(data_hck_test_dmm_2, grade), n())
data_hck_test_dmm_2$grade[data_hck_test_dmm_2$grade=="A"] <- 1
data_hck_test_dmm_2$grade[data_hck_test_dmm_2$grade=="B"] <- 2
data_hck_test_dmm_2$grade[data_hck_test_dmm_2$grade=="C"] <- 3
data_hck_test_dmm_2$grade[data_hck_test_dmm_2$grade=="D"] <- 4
data_hck_test_dmm_2$grade[data_hck_test_dmm_2$grade=="E"] <- 5
data_hck_test_dmm_2$grade[data_hck_test_dmm_2$grade=="F"] <- 6
data_hck_test_dmm_2$grade[data_hck_test_dmm_2$grade=="G"] <- 7
data_hck_test_dmm_2$grade <- as.numeric(data_hck_test_dmm_2$grade)

data_hck_test_dmm_2$int_rate <- as.numeric(substr(data_hck_test_dmm_2$int_rate, 1, nchar(data_hck_test_dmm_2$int_rate)-1))

summarise(group_by(data_hck_test_dmm_2, home_ownership), n())
data_hck_test_dmm_2$home_ownership[data_hck_test_dmm_2$home_ownership=="MORTGAGE"] <- 1
data_hck_test_dmm_2$home_ownership[data_hck_test_dmm_2$home_ownership=="OWN"] <- 2
data_hck_test_dmm_2$home_ownership[data_hck_test_dmm_2$home_ownership=="RENT"] <- 3
data_hck_test_dmm_2$home_ownership[data_hck_test_dmm_2$home_ownership=="NONE"] <- 4
data_hck_test_dmm_2$home_ownership[data_hck_test_dmm_2$home_ownership=="OTHER"] <- 5
data_hck_test_dmm_2$home_ownership <- as.numeric(data_hck_test_dmm_2$home_ownership)



#clean emp_length
summarise(group_by(data_hck_test_dmm_2, emp_length), n())
class(data_hck_test_dmm_2$emp_length)
data_hck_test_dmm_2$emp_length[data_hck_test_dmm_2$emp_length=="n/a"]<-"< 1 year"
data_hck_test_dmm_2$emp_length[str_trim(data_hck_test_dmm_2$emp_length)=="< 1 year"] <- 0
data_hck_test_dmm_2$emp_length[str_trim(data_hck_test_dmm_2$emp_length)=="1 year"] <- 1
data_hck_test_dmm_2$emp_length[str_trim(data_hck_test_dmm_2$emp_length)=="10+ years"] <- 2
data_hck_test_dmm_2$emp_length[str_trim(data_hck_test_dmm_2$emp_length)=="2 years"] <- 3
data_hck_test_dmm_2$emp_length[str_trim(data_hck_test_dmm_2$emp_length)=="3 years"] <- 4
data_hck_test_dmm_2$emp_length[str_trim(data_hck_test_dmm_2$emp_length)=="4 years"] <- 5
data_hck_test_dmm_2$emp_length[str_trim(data_hck_test_dmm_2$emp_length)=="5 years"] <- 6
data_hck_test_dmm_2$emp_length[str_trim(data_hck_test_dmm_2$emp_length)=="6 years"] <- 7
data_hck_test_dmm_2$emp_length[str_trim(data_hck_test_dmm_2$emp_length)=="7 years"] <- 8
data_hck_test_dmm_2$emp_length[str_trim(data_hck_test_dmm_2$emp_length)=="8 years"] <-9
data_hck_test_dmm_2$emp_length[str_trim(data_hck_test_dmm_2$emp_length)=="9 years"] <-10
class(data_hck_test_dmm_2$emp_length)
data_hck_test_dmm_2$emp_length<-as.numeric(data_hck_test_dmm_2$emp_length)


summarise(group_by(data_hck_test_dmm_2, verification_status), n())
class(data_hck_test_dmm_2$verification_status)
data_hck_test_dmm_2$verification_status[data_hck_test_dmm_2$verification_status=="Not Verified"] <- 0
data_hck_test_dmm_2$verification_status[data_hck_test_dmm_2$verification_status=="Source Verified"] <- 1
data_hck_test_dmm_2$verification_status[data_hck_test_dmm_2$verification_status=="Verified"] <- 2
data_hck_test_dmm_2$verification_status<-as.numeric(data_hck_test_dmm_2$verification_status)


summarise(group_by(data_hck_test_dmm_2, revol_util), n())
class(data_hck_test_dmm_2$revol_util)
data_hck_test_dmm_2$revol_util[str_trim(data_hck_test_dmm_2$revol_util)==""] <- "0%"
data_hck_test_dmm_2$revol_util <- as.numeric(substr(data_hck_test_dmm_2$revol_util, 1, nchar(data_hck_test_dmm_2$revol_util)-1))

summarise(group_by(data_hck_test_dmm_2, debt_settlement_flag), n())
data_hck_test_dmm_2$debt_settlement_flag[str_trim(data_hck_test_dmm_2$debt_settlement_flag)=="N"] <- 0
data_hck_test_dmm_2$debt_settlement_flag[str_trim(data_hck_test_dmm_2$debt_settlement_flag)=="Y"] <- 1
data_hck_test_dmm_2$debt_settlement_flag<-as.numeric(data_hck_test_dmm_2$debt_settlement_flag)
class(data_hck_test_dmm_2$debt_settlement_flag)

str(data_hck_test_dmm_2)
dim(data_hck_test_dmm_2)
head(data_hck_test_dmm_2)

sapply(data_hck_test_dmm_2, detectNAs)
cat("\014")
#Detect Space
detectSpace<-function(x){
  return(sum(is.na(str_trim(x)=="")))
}
sapply(data_hck_test_dmm_2, detectSpace)


data_hck_test_dmm_2 <- scale(data_hck_test_dmm_2)
head(data_hck_test_dmm_2)
cat("\014")
predicted <- predict(log.model, newx=data_hck_test_dmm_2, s="lambda.min", type="response")
pred_test_flag <- ifelse(predicted>0.15, 1, 0)

loanPred.data <- data.frame(LoanStatus=as.character(pred_test_flag))
write.table(loanPred.data, file = 'sanmoypaul_pm.csv', sep=",", row.names=FALSE,col.names=F)






############################## Validation Set ################
data_hck_val <- read.csv("validation.csv", stringsAsFactors = FALSE, header = TRUE)
head(data_hck_val)
tail(data_hck_val)
dim(data_hck_val)
data_hck_val_dmm_1 <- select(data_hck_val, loan_amnt,funded_amnt,funded_amnt_inv,term,int_rate,installment,grade,sub_grade,emp_title,emp_length,home_ownership,annual_inc,verification_status,issue_d,pymnt_plan,zip_code,addr_state,dti,delinq_2yrs,earliest_cr_line,inq_last_6mths,mths_since_last_delinq,mths_since_last_record,open_acc,pub_rec,revol_bal,revol_util,total_acc,initial_list_status,total_pymnt,total_pymnt_inv,total_rec_prncp,total_rec_int,total_rec_late_fee,recoveries,collection_recovery_fee,last_pymnt_d,last_pymnt_amnt,next_pymnt_d,acc_now_delinq,delinq_amnt,pub_rec_bankruptcies,tax_liens,debt_settlement_flag,debt_settlement_flag_date,settlement_status,settlement_date,settlement_amount,settlement_percentage,settlement_term)
dim(data_hck_val_dmm_1)


cat("\014")
#Detect NAs
detectNAs<-function(x){
  return(sum(is.na(x)))
}
sapply(data_hck_val_dmm_1, detectNAs)



##Clean delinq_2yrs
summarise(group_by(data_hck_val_dmm_1, delinq_2yrs), n())
data_hck_val_dmm_1$delinq_2yrs[is.na(data_hck_val_dmm_1$delinq_2yrs)] <- 0
class(data_hck_val_dmm_1$delinq_2yrs)

#clean inq_last_6mths
summarise(group_by(data_hck_val_dmm_1, inq_last_6mths), n())
data_hck_val_dmm_1$inq_last_6mths[is.na(data_hck_val_dmm_1$inq_last_6mths)] <- 0
class(data_hck_val_dmm_1$inq_last_6mths)

#clean annual_inc
data_hck_val_dmm_1$annual_inc[is.na(data_hck_val_dmm_1$annual_inc)] <- median(data_hck_val_dmm_1$annual_inc, na.rm=TRUE)
class(data_hck_val_dmm_1$annual_inc)

#clean open_acc
summarise(group_by(data_hck_val_dmm_1, open_acc), n())
data_hck_val_dmm_1 %>% 
  count(open_acc) %>%
  arrange(desc(n)) %>% 
  group_by(open_acc)

data_hck_val_dmm_1$open_acc[is.na(data_hck_val_dmm_1$open_acc)] <- 7

#clean pub_rec
summarise(group_by(data_hck_val_dmm_1, pub_rec), n())
data_hck_val_dmm_1$pub_rec[is.na(data_hck_val_dmm_1$pub_rec)] <- 0


#clean total_acc
summarise(group_by(data_hck_val_dmm_1, total_acc), n())
data_hck_val_dmm_1 %>% 
  count(total_acc) %>%
  arrange(desc(n)) %>% 
  group_by(total_acc)

data_hck_val_dmm_1$total_acc[is.na(data_hck_val_dmm_1$total_acc)] <- 21


#clean delinq_amnt
summarise(group_by(data_hck_val_dmm_1, delinq_amnt), n())

#clean acc_now_delinq
summarise(group_by(data_hck_val_dmm_1, acc_now_delinq), n())
data_hck_val_dmm_1$acc_now_delinq[is.na(data_hck_val_dmm_1$acc_now_delinq)] <- 0


#clean pub_rec_bankruptcies
summarise(group_by(data_hck_val_dmm_1, pub_rec_bankruptcies), n())

#clean tax_liens
summarise(group_by(data_hck_val_dmm_1, tax_liens), n())



#clean mths_since_last_delinq
summarise(group_by(data_hck_val_dmm_1, mths_since_last_delinq), n())
data_hck_val_dmm_1 %>% 
  count(mths_since_last_delinq) %>%
  arrange(desc(n)) %>% 
  group_by(mths_since_last_delinq)

data_hck_val_dmm_1$mths_since_last_delinq[is.na(data_hck_val_dmm_1$mths_since_last_delinq)] <- 0

dim(data_hck_val_dmm_1)
data_hck_val_dmm_2<-select(data_hck_val_dmm_1, -mths_since_last_record, -settlement_amount, -settlement_percentage, -settlement_term, -settlement_status, -settlement_date, -debt_settlement_flag_date, -emp_title, -zip_code, -addr_state, -earliest_cr_line, -last_pymnt_d, -earliest_cr_line, -issue_d, -initial_list_status, -pymnt_plan, -next_pymnt_d, -delinq_amnt, -tax_liens, -sub_grade, -delinq_amnt, -tax_liens)
dim(data_hck_val_dmm_2)
head(data_hck_val_dmm_2)

summarise(group_by(data_hck_val_dmm_2, term), n())
data_hck_val_dmm_2$term <- as.character(str_trim(data_hck_val_dmm_2$term))
data_hck_val_dmm_2$term[data_hck_val_dmm_2$term=="36 months"] <- 0
data_hck_val_dmm_2$term[data_hck_val_dmm_2$term=="60 months"] <- 1
data_hck_val_dmm_2$term <- as.numeric(data_hck_val_dmm_2$term)

summarise(group_by(data_hck_val_dmm_2, grade), n())
data_hck_val_dmm_2$grade[data_hck_val_dmm_2$grade=="A"] <- 1
data_hck_val_dmm_2$grade[data_hck_val_dmm_2$grade=="B"] <- 2
data_hck_val_dmm_2$grade[data_hck_val_dmm_2$grade=="C"] <- 3
data_hck_val_dmm_2$grade[data_hck_val_dmm_2$grade=="D"] <- 4
data_hck_val_dmm_2$grade[data_hck_val_dmm_2$grade=="E"] <- 5
data_hck_val_dmm_2$grade[data_hck_val_dmm_2$grade=="F"] <- 6
data_hck_val_dmm_2$grade[data_hck_val_dmm_2$grade=="G"] <- 7
data_hck_val_dmm_2$grade <- as.numeric(data_hck_val_dmm_2$grade)

data_hck_val_dmm_2$int_rate <- as.numeric(substr(data_hck_val_dmm_2$int_rate, 1, nchar(data_hck_val_dmm_2$int_rate)-1))

summarise(group_by(data_hck_val_dmm_2, home_ownership), n())
data_hck_val_dmm_2$home_ownership[data_hck_val_dmm_2$home_ownership=="MORTGAGE"] <- 1
data_hck_val_dmm_2$home_ownership[data_hck_val_dmm_2$home_ownership=="OWN"] <- 2
data_hck_val_dmm_2$home_ownership[data_hck_val_dmm_2$home_ownership=="RENT"] <- 3
data_hck_val_dmm_2$home_ownership[data_hck_val_dmm_2$home_ownership=="NONE"] <- 4
data_hck_val_dmm_2$home_ownership[data_hck_val_dmm_2$home_ownership=="OTHER"] <- 5
data_hck_val_dmm_2$home_ownership <- as.numeric(data_hck_val_dmm_2$home_ownership)



#clean emp_length
summarise(group_by(data_hck_val_dmm_2, emp_length), n())
class(data_hck_val_dmm_2$emp_length)
data_hck_val_dmm_2$emp_length[data_hck_val_dmm_2$emp_length=="n/a"]<-"< 1 year"
data_hck_val_dmm_2$emp_length[str_trim(data_hck_val_dmm_2$emp_length)=="< 1 year"] <- 0
data_hck_val_dmm_2$emp_length[str_trim(data_hck_val_dmm_2$emp_length)=="1 year"] <- 1
data_hck_val_dmm_2$emp_length[str_trim(data_hck_val_dmm_2$emp_length)=="10+ years"] <- 2
data_hck_val_dmm_2$emp_length[str_trim(data_hck_val_dmm_2$emp_length)=="2 years"] <- 3
data_hck_val_dmm_2$emp_length[str_trim(data_hck_val_dmm_2$emp_length)=="3 years"] <- 4
data_hck_val_dmm_2$emp_length[str_trim(data_hck_val_dmm_2$emp_length)=="4 years"] <- 5
data_hck_val_dmm_2$emp_length[str_trim(data_hck_val_dmm_2$emp_length)=="5 years"] <- 6
data_hck_val_dmm_2$emp_length[str_trim(data_hck_val_dmm_2$emp_length)=="6 years"] <- 7
data_hck_val_dmm_2$emp_length[str_trim(data_hck_val_dmm_2$emp_length)=="7 years"] <- 8
data_hck_val_dmm_2$emp_length[str_trim(data_hck_val_dmm_2$emp_length)=="8 years"] <-9
data_hck_val_dmm_2$emp_length[str_trim(data_hck_val_dmm_2$emp_length)=="9 years"] <-10
class(data_hck_val_dmm_2$emp_length)
data_hck_val_dmm_2$emp_length<-as.numeric(data_hck_val_dmm_2$emp_length)


summarise(group_by(data_hck_val_dmm_2, verification_status), n())
class(data_hck_val_dmm_2$verification_status)
data_hck_val_dmm_2$verification_status[data_hck_val_dmm_2$verification_status=="Not Verified"] <- 0
data_hck_val_dmm_2$verification_status[data_hck_val_dmm_2$verification_status=="Source Verified"] <- 1
data_hck_val_dmm_2$verification_status[data_hck_val_dmm_2$verification_status=="Verified"] <- 2
data_hck_val_dmm_2$verification_status<-as.numeric(data_hck_val_dmm_2$verification_status)


summarise(group_by(data_hck_val_dmm_2, revol_util), n())
class(data_hck_val_dmm_2$revol_util)
data_hck_val_dmm_2$revol_util[str_trim(data_hck_val_dmm_2$revol_util)==""] <- "0%"
data_hck_val_dmm_2$revol_util <- as.numeric(substr(data_hck_val_dmm_2$revol_util, 1, nchar(data_hck_val_dmm_2$revol_util)-1))

summarise(group_by(data_hck_val_dmm_2, debt_settlement_flag), n())
data_hck_val_dmm_2$debt_settlement_flag[str_trim(data_hck_val_dmm_2$debt_settlement_flag)=="N"] <- 0
data_hck_val_dmm_2$debt_settlement_flag[str_trim(data_hck_val_dmm_2$debt_settlement_flag)=="Y"] <- 1
data_hck_val_dmm_2$debt_settlement_flag<-as.numeric(data_hck_val_dmm_2$debt_settlement_flag)
class(data_hck_val_dmm_2$debt_settlement_flag)

str(data_hck_val_dmm_2)
dim(data_hck_val_dmm_2)

sapply(data_hck_val_dmm_2, detectNAs)
cat("\014")
#Detect Space
detectSpace<-function(x){
  return(sum(is.na(str_trim(x)=="")))
}
sapply(data_hck_val_dmm_2, detectSpace)


data_hck_val_dmm_2 <- scale(data_hck_val_dmm_2)
head(data_hck_val_dmm_2)
dim(data_hck_val_dmm_2)
cat("\014")
predicted_1 <- predict(log.model, newx=data_hck_val_dmm_2, s="lambda.min", type="response")
pred_test_flag_1 <- ifelse(predicted_1>=0.15, 1, 0)
pred_test_flag_1[is.na(pred_test_flag_1)]<- 1
dim(pred_test_flag_1)
list(unique(pred_test_flag_1))

loanPred.data_1 <- data.frame(LoanStatus=as.character(pred_test_flag_1))
write.csv(pred_test_flag_1, file = 'sanmoypaul_pm_1.csv')

dim(pred_test_flag_1)
