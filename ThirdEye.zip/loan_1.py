# -*- coding: utf-8 -*-
"""
Created on Wed May  1 12:34:14 2019

@author: Sanmoy
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 22:27:55 2019

@author: Sanmoy
"""

import os
path="C:\\F\\myProjects\\ThirdEye"
os.chdir(path)
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


df_loan = pd.read_csv("data/bank_loan.csv")
df_loan.head(3)
len(df_loan.columns)


##Check Missing values present in each columns
def checkMissingVal():
    print(df_loan.isnull().any())
        
checkMissingVal()

##Check value Counts of each variable
def valCounts():
    for col in df_loan.columns:
        print(df_loan[col].value_counts())
        print("\n")
        
valCounts()


##Data Exploration

##Count plot of Loan_Status
sns.countplot(x='Loan_Status',data=df_loan)

##Count plot of Loan_Status
sns.countplot(x='Loan_Status',data=df_loan, hue='Married')

sns.countplot('Loan_Status', data=df_loan, hue='Education')

sns.countplot('Loan_Status', data=df_loan, hue='Property_Area')

sns.countplot('Loan_Status', data=df_loan, hue='Self_Employed')

df_loan['LoanAmount'] = df_loan['LoanAmount'].astype(np.float64)


df_loan['LoanAmount'].hist(bins=50)

df_loan.boxplot(column='LoanAmount')


Q1 = df_loan['LoanAmount'].quantile(0.25)
Q3 = df_loan['LoanAmount'].quantile(0.75)
IQR = Q3 - Q1
print(IQR)

df_loan.shape
x = ((df_loan['LoanAmount'] < (Q1 - 1.5 * IQR)) | (df_loan['LoanAmount'] > (Q3 + 1.5 * IQR))).tolist()
t = [idx for idx, val in enumerate(x) if val]
len(t)

#df_loan_out = df_loan.drop(df_loan.index[t])
#df_loan_out.shape
df_loan_out = df_loan


## Data Cleaning
df_loan_out["Gender"] = df_loan_out["Gender"].replace({'Male':1, 'Female':0})
df_loan_out["Married"] = df_loan_out["Married"].replace({'Yes':1, 'No':0})
df_loan_out["Education"] = df_loan_out["Education"].replace({'Graduate':1, 'Not Graduate':0})
df_loan_out["Self_Employed"] = df_loan_out["Self_Employed"].replace({'Yes':1, 'No':0})
df_loan_out["Loan_Status"] = df_loan_out["Loan_Status"].replace({'Y':1, 'N':0})

Dependents = pd.get_dummies(df_loan_out['Dependents'], drop_first=True)
Property_Area = pd.get_dummies(df_loan_out['Property_Area'], drop_first=True)

df_loan_out['TotalIncome'] = df_loan_out['ApplicantIncome'] + df_loan_out['CoapplicantIncome']

df_loan_out.drop(['Loan_ID', 'ApplicantIncome', 'CoapplicantIncome', 'Dependents', 'Property_Area'], axis=1, inplace=True)
df_loan_dmy = pd.concat([df_loan_out, Dependents, Property_Area], axis=1)
df_loan_dmy.info()


cols = list(df_loan_dmy)
cols.insert(0, cols.pop(cols.index('Loan_Status')))
df_loan_dmy = df_loan_dmy.loc[:, cols]

df_loan_dmy.head(3)
len(df_loan_dmy.columns)

from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, auc, roc_auc_score
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.ensemble import RandomForestClassifier



X = df_loan_dmy.iloc[:, 1:14]
Y = df_loan_dmy.Loan_Status
X_train, X_test, y_train, y_test=train_test_split(X, Y, test_size=0.25, random_state=31)

y_test.value_counts()

#################### Random Forest ################################        
rf = RandomForestClassifier(n_estimators = 1000, max_depth = 3, random_state = 42)     
rf.fit(X_train, y_train)  

y_predRF = rf.predict(X_test)

acc_rfTest = accuracy_score(y_test, y_predRF)
print("Test Set accuracy for RF: {0}".format(acc_rfTest))

roc_RF = roc_auc_score(y_test, y_predRF)
print("Test Set ROC for RF: {0}".format(roc_RF))

cm_rf = confusion_matrix(y_test, y_predRF, labels=[1, 0])
print("===========Report for Test Set Random Forest=============")
print(cm_rf)
print(classification_report(y_test.values, y_predRF))


########### XG Boost ######################
model = XGBClassifier(objective="binary:logistic", random_state=42, eval_metric="auc", 
                      learning_rate =0.009, n_estimators=1000,
    max_depth=5, min_child_weight=5, gamma=0,subsample=0.55,colsample_bytree=0.85,
    nthread=4,scale_pos_weight=1)
model.fit(X_train, y_train, early_stopping_rounds=2, eval_set=[(X_test, y_test)])


# make predictions for test data
y_predXG = model.predict(X_test)
#predictions = [round(value) for value in y_pred]

acc_XG = accuracy_score(y_test, y_predXG)
print("Test Set accuracy for XG-Boost: {0}".format(acc_XG))

roc_XG = roc_auc_score(y_test, y_predXG)
print("Test Set ROC for XG-Boost: {0}".format(roc_XG))

print("=========== Report for Test Set XG-Boost =============")
print(confusion_matrix(y_test, y_predXG, labels=[1, 0]))
print(classification_report(y_test.values, y_predXG))



from sklearn.model_selection import GridSearchCV
param_test1 = {
    'max_depth':range(3,10,2),
    'min_child_weight':range(1,6,2),
    'learning_rate':[i/1000.0 for i in range(5,20,2)],
    'subsample':[i/100.0 for i in range(55,70,5)],
    'colsample_bytree':[i/100.0 for i in range(85,100,5)],
    'gamma':[i/100.0 for i in range(1, 2, 5)]
    
}
gsearch1 = GridSearchCV(estimator = XGBClassifier( learning_rate =0.1, 
                                                  n_estimators=1000, 
                                                  max_depth=5,
                                                  min_child_weight=1,
                                                  gamma=0, 
                                                  subsample=0.8, 
                                                  colsample_bytree=0.8,
                                                  objective= 'binary:logistic', nthread=4, scale_pos_weight=1, seed=27), 
                        param_grid = param_test1, 
                        scoring='roc_auc',
                        n_jobs=4,
                        iid=False, 
                        cv=5)

gsearch1.fit(X_train, y_train)
gsearch1.best_params_, gsearch1.best_score_



from sklearn.linear_model import LogisticRegression
logreg = LogisticRegression()
logreg.fit(X_train,y_train)
y_predLog = rf.predict(X_test)

acc_logTest = accuracy_score(y_test, y_predLog)
print("Test Set accuracy for Logistic: {0}".format(acc_logTest))

roc_log = roc_auc_score(y_test, y_predLog)
print("Test Set ROC for Logistic: {0}".format(roc_log))

cm_log = confusion_matrix(y_test, y_predLog, labels=[1, 0])
print("===========Report for Test Set Logistic =============")
print(cm_log)
print(classification_report(y_test.values, y_predLog))


