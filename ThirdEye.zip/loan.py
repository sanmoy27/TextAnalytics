# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 22:27:55 2019

@author: Sanmoy
"""

import os
path="C:\\F\\myProjects\\ThirdEye"
os.chdir(path)
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


df_loan = pd.read_csv("data/bank_loan.csv")
df_loan.head(3)
len(df_loan.columns)


##Check Missing values present in each columns
def checkMissingVal():
    print(df_loan.isnull().any())
        
checkMissingVal()

##Check value Counts of each variable
def valCounts():
    for col in df_loan.columns:
        print(df_loan[col].value_counts())
        print("\n")
        
valCounts()


##Data Exploration

##Count plot of Loan_Status
sns.countplot(x='Loan_Status',data=df_loan)

##Count plot of Loan_Status by Marital Status
sns.countplot(x='Loan_Status',data=df_loan, hue='Married')

##Count plot of Loan_Status by Education
sns.countplot('Loan_Status', data=df_loan, hue='Education')

##Count plot of Loan_Status by Property Area
sns.countplot('Loan_Status', data=df_loan, hue='Property_Area')

##Count plot of Loan_Status by Employment
sns.countplot('Loan_Status', data=df_loan, hue='Self_Employed')

df_loan['LoanAmount'] = df_loan['LoanAmount'].astype(np.float64)

df_loan['LoanAmount'].hist(bins=50)

## Box plot of Loan Amount
df_loan.boxplot(column='LoanAmount')

### Check Outliers
Q1 = df_loan['LoanAmount'].quantile(0.25)
Q3 = df_loan['LoanAmount'].quantile(0.75)
IQR = Q3 - Q1
print(IQR)

x = ((df_loan['LoanAmount'] < (Q1 - 1.5 * IQR)) | (df_loan['LoanAmount'] > (Q3 + 1.5 * IQR))).tolist()
t = [idx for idx, val in enumerate(x) if val]
len(t)

## Data Cleaning
df_loan["Gender"] = df_loan["Gender"].replace({'Male':1, 'Female':0})
df_loan["Married"] = df_loan["Married"].replace({'Yes':1, 'No':0})
df_loan["Education"] = df_loan["Education"].replace({'Graduate':1, 'Not Graduate':0})
df_loan["Self_Employed"] = df_loan["Self_Employed"].replace({'Yes':1, 'No':0})
df_loan["Loan_Status"] = df_loan["Loan_Status"].replace({'Y':1, 'N':0})


from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
df_loan["Dependents"] = le.fit_transform(df_loan["Dependents"])
df_loan["Property_Area"] = le.fit_transform(df_loan["Property_Area"])

#df_loan["Dependents"] .value_counts()
#df_loan["Property_Area"] .value_counts()

## Creation of new feature by combining two features
df_loan['TotalIncome'] = df_loan['ApplicantIncome'] + df_loan['CoapplicantIncome']
df_loan1 = df_loan
df_loan.drop(['Loan_ID', 'ApplicantIncome', 'CoapplicantIncome'], axis=1, inplace=True)
#df_loan["Property_Area"] = df_loan["Property_Area"].replace({'Semiurban':1, 'Urban':0})
#df_loan["Dependents"] = df_loan["Loan_Status"].replace({'Y':1, 'N':0})
len(df_loan.columns)
cols = list(df_loan)
cols.insert(0, cols.pop(cols.index('Loan_Status')))
df_loan = df_loan.loc[:, cols]


#from sklearn import preprocessing
#x = df_loan[['TotalIncome']].values.astype(float) #returns a numpy array
#min_max_scaler = preprocessing.MinMaxScaler()
#x_scaled = min_max_scaler.fit_transform(x)
#df_totalInc = pd.DataFrame(x_scaled)
#df_totalInc.columns=['TotalIncome']
#
#x1 = df_loan[['LoanAmount']].values.astype(float) #returns a numpy array
#x_scaled1 = min_max_scaler.fit_transform(x1)
#df_loanAmount = pd.DataFrame(x_scaled1)
#df_loanAmount.columns=['LoanAmount']
#
#x2 = df_loan[['Loan_Amount_Term']].values.astype(float) #returns a numpy array
#x_scaled2 = min_max_scaler.fit_transform(x2)
#df_loanTerm = pd.DataFrame(x_scaled2)
#df_loanTerm.columns=['Loan_Amount_Term']
#
#df_loan.drop(['TotalIncome', 'LoanAmount', 'Loan_Amount_Term'], axis=1, inplace=True)
#df_loan = pd.concat([df_loan, df_totalInc, df_loanAmount, df_loanTerm], axis=1)


df_loan.head(3)
df_loan.to_csv("loanSampleData.csv", index=False)

from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, auc, roc_auc_score
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics

## Creation of Train and Test Set
X = df_loan.iloc[:, 1:11]
Y = df_loan.Loan_Status
X_train, X_test, y_train, y_test=train_test_split(X, Y, test_size=0.25, random_state=31)


#################### Random Forest ################################        
rf = RandomForestClassifier(n_estimators = 1000, max_depth = 3, random_state = 42)     
rf.fit(X_train, y_train)  


y_predTrainRF = rf.predict(X_train)
acc_rfTrain = accuracy_score(y_train, y_predTrainRF)
print("Train Set accuracy for RF: {0}".format(acc_rfTrain))

y_predRF = rf.predict(X_test)

acc_rfTest = accuracy_score(y_test, y_predRF)
print("Test Set accuracy for RF: {0}".format(acc_rfTest))

roc_RF = roc_auc_score(y_test, y_predRF)
print("Test Set ROC for RF: {0}".format(roc_RF))

cm_rf = confusion_matrix(y_test, y_predRF, labels=[1, 0])
print("===========Report for Test Set Random Forest=============")
print(cm_rf)
print(classification_report(y_test.values, y_predRF))

fpr, tpr, _ = metrics.roc_curve(y_test, y_predRF)
auc_rf = metrics.roc_auc_score(y_test, y_predRF)
plt.plot(fpr,tpr,label="RF, auc="+str(auc_rf))
plt.legend(loc=4)
plt.show()


########### Hyperparameter Estimation of XG Boost through CV ######################
from sklearn.model_selection import GridSearchCV
param_test1 = {
    'max_depth':range(3,10,2),
    'min_child_weight':range(1,6,2),
    'learning_rate':[i/1000.0 for i in range(5,20,2)],
    'subsample':[i/100.0 for i in range(55,70,5)],
    'colsample_bytree':[i/100.0 for i in range(85,100,5)],
    'gamma':[i/100.0 for i in range(1, 2, 5)]
    
}
gsearch1 = GridSearchCV(estimator = XGBClassifier( learning_rate =0.1, 
                                                  n_estimators=1000, 
                                                  max_depth=5,
                                                  min_child_weight=1,
                                                  gamma=0, 
                                                  subsample=0.8, 
                                                  colsample_bytree=0.8,
                                                  objective= 'binary:logistic', nthread=4, scale_pos_weight=1, seed=27), 
                        param_grid = param_test1, 
                        scoring='roc_auc',
                        n_jobs=4,
                        iid=False, 
                        cv=5)

gsearch1.fit(X_train, y_train)
gsearch1.best_params_, gsearch1.best_score_


########### XG Boost ######################
model = XGBClassifier(objective="binary:logistic", random_state=42, eval_metric="auc", 
                      learning_rate=0.009, n_estimators=1000,
    max_depth=5, min_child_weight=5, gamma=0.01,subsample=0.55,colsample_bytree=0.85,
    nthread=4,scale_pos_weight=1)

model.fit(X_train, y_train, early_stopping_rounds=2, eval_set=[(X_test, y_test)])


y_predTrainXG = model.predict(X_train)
acc_XGTrain = accuracy_score(y_train, y_predTrainXG)
print("Train Set accuracy for XG: {0}".format(acc_XGTrain))

# make predictions for test data
y_predXG = model.predict(X_test)
#predictions = [round(value) for value in y_pred]

acc_XG = accuracy_score(y_test, y_predXG)
print("Test Set accuracy for XG-Boost: {0}".format(acc_XG))

roc_XG = roc_auc_score(y_test, y_predXG)
print("Test Set ROC for XG-Boost: {0}".format(roc_XG))

print("=========== Report for Test Set XG-Boost =============")
print(confusion_matrix(y_test, y_predXG, labels=[1, 0]))
print(classification_report(y_test.values, y_predXG))


########### Logistic Regression ######################
from sklearn.linear_model import LogisticRegression
logreg = LogisticRegression()
logreg.fit(X_train,y_train)
y_predLog = rf.predict(X_test)

acc_logTest = accuracy_score(y_test, y_predLog)
print("Test Set accuracy for Logistic: {0}".format(acc_logTest))

roc_log = roc_auc_score(y_test, y_predLog)
print("Test Set ROC for Logistic: {0}".format(roc_log))

cm_log = confusion_matrix(y_test, y_predLog, labels=[1, 0])
print("===========Report for Test Set Logistic =============")
print(cm_log)
print(classification_report(y_test.values, y_predLog))


